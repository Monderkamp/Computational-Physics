#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <iostream>

double rnm()
{
double a = 0.0;	
a = (double)rand()/RAND_MAX;
return a;
}